@echo off
REM Starts the Fractal Balance Game launcher with the game_venv Python.
set PY=C:\Users\BMCH\Documents\game_code\game\game_venv\Scripts\python.exe
if not exist "%PY%" (
  echo Could not find %PY%
  echo Open this file with Notepad and fix the path after "set PY="
  pause
  exit /b
)
cd /d "%~dp0"
"%PY%" game_launcher.py
if errorlevel 1 pause
